<?php

enum TrangThaiDonHang: string {
    case DANG_CHO = 'DANG_CHO';
    case DA_XAC_NHAN = 'DA_XAC_NHAN';
    case TU_CHOI = 'TU_CHOI';
    case DANG_GIAO = 'DANG_GIAO';
    case DA_GIAO = 'DA_GIAO';

}

?>
